package com.varxyz.banking.domain;

public class AccountTest {
	public static void main(String[] args) {
	}
}
