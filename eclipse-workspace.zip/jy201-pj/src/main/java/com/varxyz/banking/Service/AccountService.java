package com.varxyz.banking.Service;

import java.util.List;

public interface AccountService {
//	public void AccountServiceImpl();
//	public Account createSavingsAccount(String accountNum, double balance, double interestRate);
//	public Account createChekingsAccount(String accountNum, double balance, double overdraftAmount);
//	public void addAccount(Account account);
//	public void addAccount(Account account, String ssn);
//	public List<Account> getAccountBySsn(String ssn);
}
