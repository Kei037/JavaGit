package com.varxyz.banking.domain;

import com.varxyz.banking.Service.AccountServiceImpl;

public class AccountServiceTest {
	public static void main(String[] args) {
		
	}
}
