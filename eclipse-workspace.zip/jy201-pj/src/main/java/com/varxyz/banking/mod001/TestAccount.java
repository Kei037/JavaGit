package com.varxyz.banking.mod001;

public class TestAccount {
	public static void main(String[] args) {
		Accout a = new Accout(10000);
		System.out.println(a.getBalance());
		String s1 = "홀길동";
		System.out.println(s1);
	}
}
