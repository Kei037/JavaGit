package com.varxyz.jv251.exception;

@SuppressWarnings("serial")
public class DuplicatedEntifyException extends RuntimeException {
	public DuplicatedEntifyException(String msg) {
		super(msg);
	}
}
