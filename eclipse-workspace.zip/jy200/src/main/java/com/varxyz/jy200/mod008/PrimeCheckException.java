package com.varxyz.jy200.mod008;

public class PrimeCheckException extends Exception {
	
	public PrimeCheckException(String message) {
		super(message);
	}
}
