package com.varxyz.jy200.mod007;

public class CollageB {

}
