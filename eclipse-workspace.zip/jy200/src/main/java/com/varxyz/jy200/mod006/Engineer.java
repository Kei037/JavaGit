package com.varxyz.jy200.mod006;

public class Engineer extends Employee {
	
}
