package com.varxyz.jy200.mod004;

import java.util.Date;

public class Employee {
	String name;
	protected double salary;
	public Date birthDate;
	
	public String getDetails() {
		return "Name: " + name + "\nSalary: " + salary;
	}
	
	public void add() {
		int getPrice = 0;
		System.out.println(getPrice);
	}
}
