package com.varxyz.jy200.mod006;

public class Product {
	private String name;
	
	public Product(String name) {
		this.name = name;
	}
	
	public double getPrice() {
		return 0.0;
	}
	
	public String getName() {
		return name;
	}
	
	public String getCpu() {
		return name;
	}
}
