package com.varxyz.jy200.mod007;

public class AnimalTest {

	public static void main(String[] args) {
		Animal animal = new Dog();
		animal.makeSound();
		
		System.out.println();
		
		Animal animal2 = new Cat();
		animal2.makeSound();
	}

}
