package com.varxyz.jy200.mod001;

public class Hello {
	public String sayHello() {
		return "Hello!";
	}
}
