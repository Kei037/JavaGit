package com.varxyz.jy200.mod007;

public class Dog extends Animal {
	public void makeSound() {
		System.out.println("멍멍");
	}
	
	public void animalType() {
		if ( type == "dog") {
		
		}
	}
}
