package com.varxyz.jy200.mod001;

public class HelloTest {
	public static void main(String[] args) {
		Hello h = new Hello();
		System.out.println(h.sayHello());
	}
}
