package com.varxyz.jy200.mod006;

public class Director extends Manager {
	
}
