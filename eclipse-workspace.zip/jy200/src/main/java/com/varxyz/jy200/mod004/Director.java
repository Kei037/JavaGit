package com.varxyz.jy200.mod004;

public class Director extends Manager {
	
}
