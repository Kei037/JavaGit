package com.varxyz.jy200.mod007;

public class Cat extends Animal {
	public void makeSound() {
		System.out.println("냐옹");
	}
}
