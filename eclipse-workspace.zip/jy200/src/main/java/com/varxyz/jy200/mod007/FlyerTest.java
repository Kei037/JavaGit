package com.varxyz.jy200.mod007;

public class FlyerTest {
	public static void main(String[] args) {
		Flyer f = new Airplane();
		f.land();
	}
}