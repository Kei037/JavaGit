package com.varxyz.jy200.mod004;

public class Engineer extends Employee {
	
}
